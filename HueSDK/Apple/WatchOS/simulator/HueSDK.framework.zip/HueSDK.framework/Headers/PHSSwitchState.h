/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSSensorState.h"
#import "PHSButtonEvent.h"

@interface PHSSwitchState : PHSSensorState

/**
 Code of last switch event
 */
@property (assign, nonatomic) PHSButtonEvent buttonEvent;

@end
