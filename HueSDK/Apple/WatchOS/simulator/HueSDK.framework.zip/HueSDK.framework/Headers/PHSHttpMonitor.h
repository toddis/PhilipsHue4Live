/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>
#import "PHSObject.h"
#import "PHSHttpMonitorObserver.h"

@interface PHSHttpMonitor : PHSObject

+(void) addObserver:(id<PHSHttpMonitorObserver>) observer;
+(void) removeObserver:(id<PHSHttpMonitorObserver>) observer;

@end
