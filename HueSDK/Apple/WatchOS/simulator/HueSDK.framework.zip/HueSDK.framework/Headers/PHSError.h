/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSDomainObject.h"

@interface PHSError : PHSDomainObject

- (instancetype) init __attribute__((unavailable("init not available")));

@end
