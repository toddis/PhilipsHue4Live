/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSLightPoint.h"
#import "PHSCompoundLight.h"

@interface PHSLightSource : PHSCompoundLight

@end
