/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSBridgeResource.h"

@interface PHSTimeZones : PHSBridgeResource

@property (nonatomic, strong, readonly) NSArray<NSString *>* timeZones;

@end
