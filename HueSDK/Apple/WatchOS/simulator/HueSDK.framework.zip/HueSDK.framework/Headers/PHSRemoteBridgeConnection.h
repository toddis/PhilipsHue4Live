/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>
#import "PHSBridgeConnection.h"
#import "PHSPortalConnection.h"

@interface PHSRemoteBridgeConnection : PHSBridgeConnection<PHSPortalConnection>

@end
