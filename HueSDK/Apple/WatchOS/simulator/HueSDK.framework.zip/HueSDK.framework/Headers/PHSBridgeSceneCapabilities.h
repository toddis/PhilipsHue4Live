/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSBridgeResourceCapabilities.h"

@interface PHSBridgeSceneCapabilities : PHSBridgeResourceCapabilities

@property (nonatomic, strong, readonly) NSNumber* availableLightStates;

@end
