/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>
#import "PHSBridgeConnection.h"

@interface PHSLocalBridgeConnection : PHSBridgeConnection

@end
