/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSDomainObject.h"

@interface PHSBridgeHomekitAttributes : PHSDomainObject

/**
 Indicates wether or not the paring between the huebridge and homekit should be reset
 */
@property (strong, nonatomic) NSNumber *resetPairing;

@end
