/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

#import "PHEMessage.h"

typedef void (^PHEEntertainmentObserverBlock)(PHEMessage *message);

@protocol PHEEntertainmentObserver

- (void)onMessage:(PHEMessage *)message;

@end
