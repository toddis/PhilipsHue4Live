/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

// Generated, do not modify

#import <Foundation/Foundation.h>

#import "PHSSideloadStage.h"

@interface PHSSideloadProgress : NSObject
@property(nonatomic, assign) int numberUpdates;

@property(nonatomic, assign) int currentUpdate;

@property(nonnull, nonatomic, strong) NSString *softwareVersion;

@property(nonatomic, assign) PHSSideloadStage stage;

@property(nonatomic, assign) int64_t stageProgress;

@property(nonatomic, assign) int64_t stageTotal;

@end
