/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

// Generated, do not modify

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, PHSSideloadResult) {
  PHSSideloadResultSuccess,
  PHSSideloadResultInvalidBridge,
  PHSSideloadResultInvalidBridgeConfiguration,
  PHSSideloadResultWebserviceRequestError,
  PHSSideloadResultFirmwareDownloadError,
  PHSSideloadResultFirmwareSideloadError,
  PHSSideloadResultBridgeRebootTimeout,
  PHSSideloadResultBridgeNotConnected,
  PHSSideloadResultInvalidPreDownloadedFirmware
};

@interface PHSOptionalSideloadResult : NSObject
@property(nonatomic) PHSSideloadResult value;

- (instancetype)init __attribute__((unavailable("use initWith constructor")));
- (instancetype)initWith:(PHSSideloadResult)value;
@end
