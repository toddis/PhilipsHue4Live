/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

#import "PHEMessageData.h"
#import "PHELight.h"

@interface PHERenderMessageData : NSObject<PHEMessageData>

@property (nonatomic, strong, readonly) NSArray<PHELight*>* lights;

@end
