/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

// Generated, do not modify

#import <Foundation/Foundation.h>

@interface PHSSideloadSoftwareUpdateInfo : NSObject
@property(nonatomic, assign) int64_t softwareVersion;

@property(nonnull, nonatomic, strong) NSString *versionUrl;

@property(nonatomic, assign) int64_t fileSize;

/**
 * This is Base64 encoded when pre-downloaded and passed to the Sideloader.
 * It is empty when returned by the Sideloader.
 */
@property(nonnull, nonatomic, strong) NSString *blob;

@end
