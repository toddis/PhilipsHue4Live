/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSSchedule.h"

@interface PHSTimer : PHSSchedule

/**
 The time this timer was started
 */
@property (strong, nonatomic) NSDate *startTime;

@end
