/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, PHSBridgeDiscoveryStatus) {
  PHSBridgeDiscoveryStatusSuccess,
  PHSBridgeDiscoveryStatusCanceled,
  PHSBridgeDiscoveryStatusBridgeDiscoveryFailure,
  PHSBridgeDiscoveryStatusBridgeNotFound
};
