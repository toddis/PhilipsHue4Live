/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSBridgeResource.h"

@interface PHSBridgeResourceCapabilities : PHSBridgeResource

@property (nonatomic, strong, readonly) NSNumber* availableResources;

@end
