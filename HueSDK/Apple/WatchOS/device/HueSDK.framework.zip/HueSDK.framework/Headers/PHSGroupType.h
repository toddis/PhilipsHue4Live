/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, PHSGroupType) {
    PHSGroupTypeUnknown    = -1,
    PHSGroupTypeLightGroup = 0,
    PHSGroupTypeLightSource,
    PHSGroupTypeLuminaire,
    PHSGroupTypeRoom,
    PHSGroupTypeEntertainment,
    PHSGroupTypeZone  // as of clip spec 1.30
};
