/*******************************************************************************
Copyright (C) 2019 Signify Holding
All Rights Reserved.
********************************************************************************/

#import <Foundation/Foundation.h>

@protocol PHSSubscription <NSObject>
- (void) enable;
- (void) disable;
@end