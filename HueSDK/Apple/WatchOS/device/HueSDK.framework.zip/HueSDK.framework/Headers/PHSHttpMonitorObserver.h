/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSHttpRequest.h"
#import "PHSHttpResponse.h"
#import "PHSHttpRequestError.h"

@protocol PHSHttpMonitorObserver

- (void) onRequestPerformed:(PHSHttpRequest*) request status:(int) status;
- (void) onResponseReceived:(PHSHttpResponse*) response error:(PHSHttpRequestError*) error;

@end
