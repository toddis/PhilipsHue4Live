/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

typedef NS_ENUM(NSInteger, PHELightIteratorEffectOrder) {
    PHELightIteratorEffectOrderLeftRight,
    PHELightIteratorEffectOrderFrontBack,
    PHELightIteratorEffectOrderClockWise,
    PHELightIteratorEffectOrderInOut,
    PHELightIteratorEffectOrderRandom,
    PHELightIteratorEffectOrderGroup
};

typedef NS_ENUM(NSInteger, PHELightIteratorEffectMode) {
    PHELightIteratorEffectModeSingle,
    PHELightIteratorEffectModeCycle,
    PHELightIteratorEffectModeBounce
};
