/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

typedef NS_ENUM(NSInteger, PHSPortalConnectionErrorCode) {
    PHSPortalConnectionErrorCodeUnknown,
    PHSPortalConnectionErrorCodeNotAllowed,
    PHSPortalConnectionErrorCodeBadReqeust,
    PHSPortalConnectionErrorCodeLoginRequired,
    PHSPortalConnectionErrorCodeInvalidRequest,
    PHSPortalConnectionErrorCodeInvalidClient,
    PHSPortalConnectionErrorCodeAuthorizationCodeExpired,
    PHSPortalConnectionErrorCodeAccessTokenMissing,
    PHSPortalConnectionErrorCodeAccessTokenBad,
    PHSPortalConnectionErrorCodeAccessTokenExpired
};
