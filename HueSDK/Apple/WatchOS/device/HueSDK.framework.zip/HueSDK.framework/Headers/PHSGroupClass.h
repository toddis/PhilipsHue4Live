/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, PHSGroupClass) {
    PHSGroupClassUnknown = -1,
    PHSGroupClassNone    = 0,

    // Rooms (and Zones as of clip spec 1.30)
    PHSGroupClassLivingGroup,
    PHSGroupClassKitchen,
    PHSGroupClassDining,
    PHSGroupClassBedGroup,
    PHSGroupClassKidsBedGroup,
    PHSGroupClassBathGroup,
    PHSGroupClassNursery,
    PHSGroupClassRecreation,
    PHSGroupClassOffice,
    PHSGroupClassGym,
    PHSGroupClassHallway,
    PHSGroupClassToilet,
    PHSGroupClassFrontDoor,
    PHSGroupClassGarage,
    PHSGroupClassTerrace,
    PHSGroupClassGarden,
    PHSGroupClassDriveway,
    PHSGroupClassCarport,
    
    // Entertainment
    PHSGroupClassTV,
    PHSGroupClassFree,
    
    PHSGroupClassOther,

    // Rooms & Zones : group class additions as of clip spec 1.30
    PHSGroupClassHome,
    PHSGroupClassDownStairs,
    PHSGroupClassUpStairs,
    PHSGroupClassTopFloor,
    PHSGroupClassAttic,
    PHSGroupClassGuestRoom,
    PHSGroupClassStairCase,
    PHSGroupClassLounge,
    PHSGroupClassManCave,
    PHSGroupClassComputer,
    PHSGroupClassStudio,
    PHSGroupClassMusic,
        // PHSGroupClassTV, previously introduced in clip spec 1.22, for group-type Entertainment
    PHSGroupClassReading,
    PHSGroupClassCloset,
    PHSGroupClassStorage,
    PHSGroupClassLaundryRoom,
    PHSGroupClassBalcony,
    PHSGroupClassPorch,
    PHSGroupClassBarbecue,
    PHSGroupClassPool
};
