/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

#import "PHSReturnCode.h"

@class PHSError;
@class PHSClipResponse;

typedef void (^PHSBridgeResponseCompletionHandler)(NSArray<PHSClipResponse*> *responses, NSArray<PHSError*> *errors, PHSReturnCode returnCode);
