/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSError.h"
#import "PHSReturnCode.h"

@interface PHSSDKError : PHSError

/**
 The http error message
 */
@property(strong, nonatomic, readonly) NSString *errorMessage;

/**
 The SDK error code
 */
@property(assign, nonatomic, readonly) PHSReturnCode errorCode;

@end
