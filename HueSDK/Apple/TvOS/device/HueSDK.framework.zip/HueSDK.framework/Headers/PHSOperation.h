/*******************************************************************************
Copyright (C) 2019 Signify Holding
All Rights Reserved.
********************************************************************************/

#import <Foundation/Foundation.h>

@protocol PHSOperation <NSObject>
- (void) wait;
- (void) cancel;
- (BOOL) isCancelable;
@end
