/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSSensorConfiguration.h"

@interface PHSPresenceSensorConfiguration : PHSSensorConfiguration

/**
 The sensitivity of the presence sensor
 */
@property (strong, nonatomic) NSNumber* sensitivity;

/**
 The maximum sensitivity of the presence sensor
 */
@property (strong, nonatomic, readonly) NSNumber* maximumSensitivity;

@end
