/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

#import "PHERepeatableAnimation.h"

@interface PHETriggerableAnimation : PHERepeatableAnimation

- (instancetype) init;
- (instancetype) initWithRepeatCount:(double)repeatCount;

- (void)trigger:(NSString*)bookmark;
- (void)triggerOnLevel:(NSString *)bookmark;

- (double)offset;

@end
