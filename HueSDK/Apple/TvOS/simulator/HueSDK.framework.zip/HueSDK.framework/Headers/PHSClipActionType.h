/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

typedef NS_ENUM(NSInteger, PHSClipActionType) {
    PHSClipActionTypeUnknownAction = 0,
    PHSClipActionTypeUpdateDeviceState,
    PHSClipActionTypeUpdateDeviceConfiguration,
    PHSClipActionTypeDeleteDevice,
    PHSClipActionTypeSetGroupState,
    PHSClipActionTypeRecallResource,
    PHSClipActionTypeCreateResource,
    PHSClipActionTypeDeleteResource,
    PHSClipActionTypeUpdateResource
};
