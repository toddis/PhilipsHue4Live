/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, PHSLightEffectMode) {
    PHSLightEffectModeUnknown = -1, // It is unknown what the current effect value is
    PHSLightEffectModeNone = 0, // No effect active
    PHSLightEffectModeColorLoop = 1 // Colorloop effect (loop through colors with current saturation and brightness)
};
