/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSObject.h"

@interface PHSKnowledgeBase : PHSObject

- (instancetype) init __attribute__((unavailable("init not available")));

@end
