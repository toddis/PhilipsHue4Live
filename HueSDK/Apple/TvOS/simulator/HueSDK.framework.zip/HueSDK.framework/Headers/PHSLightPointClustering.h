/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

#import "PHSLightPointCluster.h"

@interface PHSLightPointClustering : NSObject

- (NSArray<PHSLightPointCluster *> *) cluster:(NSArray<PHSLightPoint *> *)lightPoints;

@end
