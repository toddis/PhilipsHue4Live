/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

#import "PHSDomainObject.h"
#import "PHSDeviceSoftwareUpdateState.h"

@interface PHSDeviceSoftwareUpdate : PHSDomainObject

@property (assign, nonatomic) PHSDeviceSoftwareUpdateState updateState;

@property (strong, nonatomic) NSDate *lastInstall;

@end
