/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

#import "PHETimeline.h"
#import "PHEMessageData.h"

@interface PHETimelineMessageData : NSObject<PHEMessageData>

@property (nonatomic, weak, readonly) PHETimeline* timeline;

@end
