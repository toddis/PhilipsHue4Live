/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSBridgeResource.h"
#import "PHSBridgeResourceCapabilities.h"
#import "PHSDomainType.h"

@interface PHSBridgeCapabilities : PHSBridgeResource

@property (nonatomic, strong, readonly) NSDictionary<NSNumber*, PHSBridgeResourceCapabilities*>* bridgeResourceCapabilities;

- (PHSBridgeResourceCapabilities*) capabilitiesForDomainType:(PHSDomainType)domainType;

@end
