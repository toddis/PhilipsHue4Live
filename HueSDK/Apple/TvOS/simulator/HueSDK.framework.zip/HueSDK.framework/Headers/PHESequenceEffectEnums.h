/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

typedef NS_ENUM(NSInteger, PHESequenceEffectMode) {
    PHESequenceEffectModeAll,
    PHESequenceEffectModeRound,
    PHESequenceEffectModeBack,
    PHESequenceEffectModeRight,
    PHESequenceEffectModeLast
};
