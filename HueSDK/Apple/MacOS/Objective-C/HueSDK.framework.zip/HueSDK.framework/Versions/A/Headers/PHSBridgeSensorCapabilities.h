/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSSensor.h"
#import "PHSBridgeResourceCapabilities.h"

@interface PHSBridgeSensorCapabilities : PHSBridgeResourceCapabilities

- (NSNumber *)availableSensorsForSubType:(PHSSensorSubType)subType;

@end
