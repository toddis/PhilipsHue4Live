/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

// Generated, do not modify

#import <Foundation/Foundation.h>

@interface PHSBridgeDiscoveryResult : NSObject

@property(nonnull, nonatomic, strong) NSString *uniqueId;
@property(nonnull, nonatomic, strong) NSString *ip;
@property(nonnull, nonatomic, strong) NSString *apiVersion;
@property(nonnull, nonatomic, strong) NSString *modelId;

- (nonnull instancetype)initWithUniqueId:(nonnull NSString *)uniqueId
                                      ip:(nonnull NSString *)ip
                              apiVersion:(nonnull NSString *)apiVersion
                                 modelId:(nonnull NSString *)modelId;

@end
