/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

@interface PHELocation : NSObject

@property (nonatomic, assign) double x;
@property (nonatomic, assign) double y;

- (instancetype)initWithX:(double)x andY:(double)y;

@end
