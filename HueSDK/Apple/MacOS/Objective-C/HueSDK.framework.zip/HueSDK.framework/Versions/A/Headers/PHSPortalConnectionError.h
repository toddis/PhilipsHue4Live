/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSHttpError.h"
#import "PHSPortalConnectionErrorCode.h"

@interface PHSPortalConnectionError : PHSHttpError

/**
 The remote connection error code
 */
@property(nonatomic,readonly) PHSPortalConnectionErrorCode error;

@end
