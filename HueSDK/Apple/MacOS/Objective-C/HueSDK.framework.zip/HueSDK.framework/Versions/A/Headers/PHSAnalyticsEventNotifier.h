/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

typedef void (^PHSAnalyticsEventListener)(
    NSString* _Nonnull name, NSDictionary<NSString *, NSString *> * _Nonnull data);

@protocol PHSAnalyticsEventNotifierProtocol <NSObject>

/**
 Register the notifier globally in the SDK
 */
- (void)registerListener:(PHSAnalyticsEventListener _Nonnull)listener;

@end

@interface PHSAnalyticsEventNotifier : NSObject <PHSAnalyticsEventNotifierProtocol>

- (nonnull instancetype)init
    __attribute__((unavailable("use one of the initWith constructors")));

/**
 Register the notifier globally in the SDK
 */
- (void)registerListener:(PHSAnalyticsEventListener _Nonnull)listener;

@end
