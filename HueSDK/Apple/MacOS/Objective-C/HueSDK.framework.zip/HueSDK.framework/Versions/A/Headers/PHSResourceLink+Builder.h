/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

#import "PHSResourceLink.h"
#import "PHSResourceLinkBuilder.h"

@interface PHSResourceLink (Builder)

/**
 create a resourceLink with a builder block
 */
+ (instancetype) resourceLinkWithBlock:(void(^)(PHSResourceLinkBuilder *builder))builderBlock;
  
@end
