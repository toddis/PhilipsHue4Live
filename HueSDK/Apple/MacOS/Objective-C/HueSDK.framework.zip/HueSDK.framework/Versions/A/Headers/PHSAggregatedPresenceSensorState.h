/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

// Generated, do not modify

#import <Foundation/Foundation.h>

#import "Foundation/Foundation.h"

@interface PHSAggregatedPresenceSensorState : NSObject
@property(nullable, nonatomic, strong) NSDate *lastUpdated;

@property(nullable, nonatomic, strong) NSNumber *presence;

@property(nullable, nonatomic, strong) NSNumber *presenceAll;

@end
