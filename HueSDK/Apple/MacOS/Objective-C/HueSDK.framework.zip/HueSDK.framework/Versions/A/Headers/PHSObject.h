/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

#define METHOD_UNAVAILABLE(msg) __attribute__((unavailable(msg)))

@interface PHSObject : NSObject

@end
