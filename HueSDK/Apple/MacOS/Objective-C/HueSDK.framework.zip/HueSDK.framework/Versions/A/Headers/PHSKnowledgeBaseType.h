/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

typedef NS_ENUM(NSInteger, PHSKnowledgeBaseType) {
    PHSKnowledgeBaseTypeLights        = 0,
    PHSKnowledgeBaseTypeImage         = 1,
    PHSKnowledgeBaseTypeManufacturers = 2
};
