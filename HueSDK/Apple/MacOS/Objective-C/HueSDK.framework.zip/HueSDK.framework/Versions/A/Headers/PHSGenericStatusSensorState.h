/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSSensorState.h"

@interface PHSGenericStatusSensorState : PHSSensorState

/**
 sensor status, expressed as integer
 */
@property (strong, nonatomic) NSNumber* status;

@end
