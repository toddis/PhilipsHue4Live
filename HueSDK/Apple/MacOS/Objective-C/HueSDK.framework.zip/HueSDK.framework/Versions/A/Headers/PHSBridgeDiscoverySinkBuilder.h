/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

#import "PHSBridge.h"
#import "PHSBridgeDiscoveryStatus.h"
#import "PHSBridgeDiscoverySink.h"
#import "PHSBridgeUniqueId.h"

typedef void (^PHSBridgesDiscoveredHandler) (NSOrderedSet<PHSBridgeUniqueId*>* _Nonnull foundBridges, NSOrderedSet<PHSBridgeUniqueId*>* _Nonnull ignoredBridges);
typedef void (^PHSBridgeInitializedHandler) (PHSBridge* _Nonnull bridge);
typedef void (^PHSSearchDoneHandler) (PHSBridgeDiscoveryStatus status);

/*
 * Sink builder responsible for building a sink that delegates messages to std::function handlers.
 */
@interface PHSBridgeDiscoverySinkBuilder : NSObject

/**
 * Sets onBridgesDiscovered handler
 * @param handler onBridgesDiscovered handler
 * @return current builder object
 */
- (PHSBridgeDiscoverySinkBuilder* _Nonnull) onBridgesDiscovered:(PHSBridgesDiscoveredHandler _Nonnull) handler;

/**
 * Sets onBridgeInitialized handler
 * @param handler onBridgeInitialized handler
 * @return current builder object
 */
- (PHSBridgeDiscoverySinkBuilder* _Nonnull) onBridgeInitialized:(PHSBridgeInitializedHandler _Nonnull) handler;

/**
 * Sets onDone handler
 * @param handler onDone handler
 * @return current builder object
 */
- (PHSBridgeDiscoverySinkBuilder* _Nonnull) onDone:(PHSSearchDoneHandler _Nonnull) handler;

/**
 * Creates sink which delegates messages to the provided handlers
 * @return bridge discovery sink
 */
- (id<PHSBridgeDiscoverySink> _Nonnull) build;

@end
