/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSObject.h"

@interface PHSManufacturer : PHSObject

- (instancetype) init __attribute__((unavailable("init not available")));

/**
 The identifier
 */
@property (strong, nonatomic, readonly) NSString *identifier;

/**
 The manufacturer
 */
@property (strong, nonatomic, readonly) NSString *manufacturer;

@end
