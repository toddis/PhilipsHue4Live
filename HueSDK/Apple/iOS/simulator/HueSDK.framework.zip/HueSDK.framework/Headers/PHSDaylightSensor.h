/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSSensor.h"

@interface PHSDaylightSensor : PHSSensor

- (instancetype) init __attribute__((unavailable("init not available")));

@end
