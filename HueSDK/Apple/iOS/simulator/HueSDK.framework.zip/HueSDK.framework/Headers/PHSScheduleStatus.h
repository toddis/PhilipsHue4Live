/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, PHSScheduleStatus) {
    PHSScheduleStatusUnknown = -1,
    PHSScheduleStatusNone = 0,
    PHSScheduleStatusEnable = 1,             // Settable to bridge
    PHSScheduleStatusDisable = 2,            // Settable to bridge
    PHSScheduleStatusErrors = 3
};
