/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSDomainObject.h"
#import "PHSBridgeBackupStatus.h"
#import "PHSBridgeBackupErrorCode.h"

@interface PHSBridgeBackup : PHSDomainObject

/**
 The current status code of the backup
 */
@property (assign, nonatomic) PHSBridgeBackupStatus status;

/**
 The error code
 */
@property (assign, nonatomic, readonly) PHSBridgeBackupErrorCode errorCode;

@end
