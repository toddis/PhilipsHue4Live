/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

#import "PHSReturnCode.h"

typedef void (^PHSBridgeHttpResponseSuccessCompletionHandler)(NSString* _Nonnull body, NSInteger statusCode);
typedef void (^PHSBridgeHttpResponseErrorCompletionHandler)(NSInteger returnCode);