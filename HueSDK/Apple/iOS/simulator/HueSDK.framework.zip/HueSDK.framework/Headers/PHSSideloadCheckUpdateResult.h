/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

// Generated, do not modify

#import <Foundation/Foundation.h>

#import "PHSSideloadResult.h"
#import "PHSSideloadSoftwareUpdateInfo.h"

@interface PHSSideloadCheckUpdateResult : NSObject
@property(nonatomic, assign) PHSSideloadResult result;

@property(nonnull, nonatomic, strong)
    NSArray<PHSSideloadSoftwareUpdateInfo *> *updateList;

@end
