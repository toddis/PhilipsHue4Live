/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSSensorConfiguration.h"

@interface PHSGeofenceSensorConfiguration : PHSSensorConfiguration

/**
 Radius in meters
 */
@property (nonatomic, strong) NSNumber *radius;

/**
 Device name of the device triggering the fence
 */
@property (nonatomic, strong) NSString *device;

@end
