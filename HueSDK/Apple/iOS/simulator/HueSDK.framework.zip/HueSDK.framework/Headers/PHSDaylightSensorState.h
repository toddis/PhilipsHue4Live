/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSSensorState.h"

@interface PHSDaylightSensorState : PHSSensorState

/**
 Whether it's daylight (boolean)
 */
@property (strong, nonatomic) NSNumber *daylight;

@end
