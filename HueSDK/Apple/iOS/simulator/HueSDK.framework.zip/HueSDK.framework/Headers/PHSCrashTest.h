/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>
#import "PHSObject.h"

@interface PHSCrashTest : PHSObject

/**
  Invoke SIGABRT signal
 */
+ (void)invokeSigabrt;

/**
  Invoke SIGABRT signal
 */
+ (void)invokeSigsegv;

@end;

