/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSObject.h"
#import "PHSDomainObject.h"

@interface PHSTimePattern : PHSObject

@end
