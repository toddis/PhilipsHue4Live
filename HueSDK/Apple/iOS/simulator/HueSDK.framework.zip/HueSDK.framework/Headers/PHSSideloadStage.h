/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

// Generated, do not modify

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, PHSSideloadStage) {
  PHSSideloadStageCheckingService,
  PHSSideloadStageDownloadingFirmware,
  PHSSideloadStageSideloadingFirmware,
  PHSSideloadStageRebootingBridge
};

@interface PHSOptionalSideloadStage : NSObject
@property(nonatomic) PHSSideloadStage value;

- (instancetype)init __attribute__((unavailable("use initWith constructor")));
- (instancetype)initWith:(PHSSideloadStage)value;
@end
