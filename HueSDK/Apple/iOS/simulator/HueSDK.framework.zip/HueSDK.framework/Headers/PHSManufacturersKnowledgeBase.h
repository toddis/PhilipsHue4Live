/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSKnowledgeBase.h"

@interface PHSManufacturersKnowledgeBase : PHSKnowledgeBase

/**
 The manufacturers
 */
@property (strong, nonatomic, readonly) NSDictionary *manufacturers;

@end
