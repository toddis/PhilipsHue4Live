/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

#import "PHSCancelableOperation.h"
#import "PHSBridgeDiscoverySink.h"
#import "PHSBridgeUniqueId.h"
#import "PHSBridgeDiscovery.h"

/**
 * This class provides higher level bridge discovery APIs. In contrast to BridgeDiscovery module, it also tries to
 * authenticate found bridges and the one that is authenticated first is provided as final result to the user.
 *
 * BridgeDiscoverySink is used as a communication channel between the service and the user. User can get
 * intermediate results by handling the following events:
 * - BridgeDiscoverySink.onBridgesDiscovered, searching for bridges in the network is done, service continues
 *   to authenticate bridges from found_bridges list. IDs of bridges that were found but ignored can be found
 *   in ignored_bridges list.
 * - BridgeDiscoverySink.onBridgeInitialized, one of the bridges is successfully authenticated
 * - BridgeDiscoverySink.onDone, operation is done. After this event user cannot receive any other event, it can
 *   destroy the resources used for handling bridge discovery events.
 *
 * This API is asynchronous, operation lifespan can be controlled using Operation instance returned by these APIs:
 * - User can cancel triggered operation by calling [CancelableOperation.cancel].
 * - User can block his thread while operation is not done by calling [CancelableOperation.waitFinished].
 *
 * User doesn't have to keep operation instance alive. If [CancelableOperation] operation is destroyed then discovery
 * operation continues working.
 */
@protocol PHSBridgeDiscoveryService <NSObject>

/**
 * Start searching for any bridge in the network using default discovery methods
 * @param sink                  message sink that handles all messages connected with triggered operation
 * @return                      cancelable operation instance
 */
- (id <PHSCancelableOperation> _Nonnull)find:(nonnull id <PHSBridgeDiscoverySink>)sink;

/**
 * Start searching for a certain bridge on the given network.
 * @param bridgeUniqueId        ID of the bridge that we are looking for.
 * @param methods               Methods that should be used for searching the bridge
 * @param sink                  message sink that handles all messages connected with triggered operation
 * @return                      cancelable operation instance
 */
- (id <PHSCancelableOperation> _Nonnull)findBridgeWithId:(PHSBridgeUniqueId* _Nonnull)bridgeUniqueId
                                                 methods:(PHSBridgeDiscoveryOption)methods
                                                    sink:(nonnull id <PHSBridgeDiscoverySink>)sink;

/**
 * Start searching for any other bridge than those specified in exclude_list
 * @param bridgesToExclude      IDs of the bridges that need to be excluded from discovering
 * @param methods               Methods that should be used for searching the bridge
 * @param sink                  message sink that handles all messages connected with triggered operation
 * @return                      cancelable operation instance
 */
- (id <PHSCancelableOperation> _Nonnull)findExcludingBridges:(nonnull NSOrderedSet<PHSBridgeUniqueId*>*)bridgesToExclude
                                                     methods:(PHSBridgeDiscoveryOption)methods
                                                        sink:(nonnull id <PHSBridgeDiscoverySink>)sink;

/**
 * Method connects with a bridge on the given ip_address. If device behind that IP is not reachable or
 * it is not a bridge then user gets BRIDGE_NOT_FOUND as status of sink::on_done message
 * ipAddress                    device ip address
 * sink                         message sink that handles all messages connected with triggered operation
 */
- (id <PHSCancelableOperation> _Nonnull)connectToIp:(nonnull NSString*)ipAddress
                                               sink:(nonnull id <PHSBridgeDiscoverySink>)sink;

@end
