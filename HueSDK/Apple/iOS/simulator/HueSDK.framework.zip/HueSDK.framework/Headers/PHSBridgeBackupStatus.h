/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, PHSBridgeBackupStatus) {
    PHSBridgeBackupStatusUnknown = -1,
    PHSBridgeBackupStatusIdle = 0,
    PHSBridgeBackupStatusStartMigration,
    PHSBridgeBackupStatusFilereadyDisabled,
    PHSBridgeBackupStatusPrepareRestore,
    PHSBridgeBackupStatusRestoring,
};
