/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSSensorState.h"
#import "PHSButtonEvent.h"

@interface PHSGeofenceSensorState : PHSSensorState

/**
 Whether presence is detected
 */
@property (strong, nonatomic) NSNumber *presence;

@end
