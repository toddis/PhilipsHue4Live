/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>
#import "PHSCompoundDevice.h"
#import "PHSSensor.h"

@interface PHSCompoundSensor : PHSSensor<PHSCompoundDevice>

@end
