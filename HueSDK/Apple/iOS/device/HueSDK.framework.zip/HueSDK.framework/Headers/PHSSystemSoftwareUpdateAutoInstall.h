/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

#import "PHSDomainObject.h"
#import "PHSTruncatedTimePattern.h"

@interface PHSSystemSoftwareUpdateAutoInstall : PHSDomainObject

@property (strong, nonatomic) NSNumber *on;

@property (strong, nonatomic) PHSTruncatedTimePattern *updateTime;

@property (assign, nonatomic) BOOL isSupported;

@end
