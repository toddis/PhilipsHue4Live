/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, PHSConnectionState) {
    PHSConnectionStateUnknown = -1,
    PHSConnectionStateDisconnected = 0,
    PHSConnectionStateConnected,
};
