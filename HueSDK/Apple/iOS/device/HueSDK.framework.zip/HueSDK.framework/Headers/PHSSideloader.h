/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

// Generated, do not modify

#import <Foundation/Foundation.h>

#import "PHSBridge.h"
#import "PHSSideloadCheckUpdateResult.h"
#import "PHSSideloadProgress.h"
#import "PHSSideloadResult.h"
#import "PHSSideloadSoftwareUpdateInfo.h"

typedef void (^PHSSideloaderCallback)(PHSSideloadProgress *_Nullable progress);

@interface PHSSideloader : NSObject

@property(nonnull, nonatomic, strong) NSString *checkUpdateEndpoint;

/**
 * Note: the callback will be called synchronously on the same thread calling
 * this method
 */
- (PHSSideloadResult)downloadAndUpdateFirmware:(nullable PHSBridge *)bridge
                        progressReportCallback:(nullable PHSSideloaderCallback)
                                                   progressReportCallback;

- (PHSSideloadResult)
downloadAndUpdateFirmware:(nullable PHSBridge *)bridge
   progressReportCallback:(nullable PHSSideloaderCallback)progressReportCallback
    preDownloadedFirmware:(nullable NSArray<PHSSideloadSoftwareUpdateInfo *> *)
                              preDownloadedFirmware;

- (BOOL)isMandatoryUpdateAvailable:(nullable PHSBridge *)bridge;

- (nullable PHSSideloadCheckUpdateResult *)checkNewFirmwareAvailable:
    (nullable PHSBridge *)bridge;

@end
