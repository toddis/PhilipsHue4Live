/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSDomainObject.h"

@class PHSBridge;

@interface PHSBridgeResource : PHSDomainObject

/**
 The bridge resource indentifier
 */
@property (strong, nonatomic) NSString *identifier;

/**
 The bridge resource name
 */
@property (strong, nonatomic) NSString *name;

@end
