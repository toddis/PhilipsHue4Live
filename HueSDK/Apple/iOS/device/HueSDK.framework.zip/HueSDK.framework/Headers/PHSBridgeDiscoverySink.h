/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

#import "PHSBridge.h"
#import "PHSBridgeDiscoveryStatus.h"
#import "PHSBridgeUniqueId.h"

/*
 * Sink responsible for handling bridge discovery operation messages.
 */
@protocol PHSBridgeDiscoverySink<NSObject>

/**
 * Method triggered when network analysis is done. Next step is trying to connect with unknown bridges.
 * @param foundBridges       ids of the bridges found in the given network
 * @param ignoredBridges     ids of bridges found in the given network but ignored
 */
- (void)onBridgesDiscovered:(nonnull NSOrderedSet<PHSBridgeUniqueId*>*)foundBridges
             ignoredBridges:(nonnull NSOrderedSet<PHSBridgeUniqueId*>*)ignoredBridges;

/**
 * Method triggered when some of the found bridges is authenticated and connected
 * @param bridge    instance of the bridge that was authenticated successfully
 */
- (void)onBridgeInitialized:(nonnull PHSBridge *)bridge;

/**
 * Method triggered when bridge discovery is done.
 * @param status    operation status.
 */
- (void)onDone:(PHSBridgeDiscoveryStatus)status;

@end
