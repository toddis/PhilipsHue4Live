/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

#import "PHSBridgeDiscoveryService.h"

@interface PHSBridgeDiscoveryServiceFactory : NSObject

/**
 * Creates a new bridge discovery service instance
 * @return bridge discovery instance
 */
- (id <PHSBridgeDiscoveryService> _Nonnull)createWithAppName:(NSString* _Nonnull)appName deviceName: (NSString* _Nonnull)deviceName;

@end
