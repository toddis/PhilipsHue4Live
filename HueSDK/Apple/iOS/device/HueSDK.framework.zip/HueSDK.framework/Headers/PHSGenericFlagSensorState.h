/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSSensorState.h"

@interface PHSGenericFlagSensorState : PHSSensorState

/**
 sensor status, expressed as boolean
 */
@property (strong, nonatomic) NSNumber* flag;

@end
