/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSSensorConfiguration.h"

@interface PHSOpenCloseSensorConfiguration : PHSSensorConfiguration

@end
