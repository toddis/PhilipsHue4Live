/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import <Foundation/Foundation.h>

#import "PHSBridgeHttpResponseCompletionHandler.h"
#import "PHSBridgeConnectionType.h"

@interface PHSBridgeHttpClient: NSObject

- (id)initWithBridge:(PHSBridge*)bridge;

- (void)doGet: (NSString*)resourcePath
        callbackSuccess:(PHSBridgeHttpResponseSuccessCompletionHandler)callbackSuccess
        callbackError:(PHSBridgeHttpResponseErrorCompletionHandler)callbackError
        allowedConnectionTypes:(PHSBridgeConnectionType)allowedConnectionTypes;

- (void)doPost: (NSString*)resourcePath
        body:(NSString*)body
        callbackSuccess:(PHSBridgeHttpResponseSuccessCompletionHandler)callbackSuccess
        callbackError:(PHSBridgeHttpResponseErrorCompletionHandler)callbackError
        allowedConnectionTypes:(PHSBridgeConnectionType)allowedConnectionTypes;

- (void)doPut: (NSString*)resourcePath
        body:(NSString*)body
        callbackSuccess:(PHSBridgeHttpResponseSuccessCompletionHandler)callbackSuccess
        callbackError:(PHSBridgeHttpResponseErrorCompletionHandler)callbackError
        allowedConnectionTypes:(PHSBridgeConnectionType)allowedConnectionTypes;

- (void)doDelete: (NSString*)resourcePath
        callbackSuccess:(PHSBridgeHttpResponseSuccessCompletionHandler)callbackSuccess
        callbackError:(PHSBridgeHttpResponseErrorCompletionHandler)callbackError
        allowedConnectionTypes:(PHSBridgeConnectionType)allowedConnectionTypes;

@end