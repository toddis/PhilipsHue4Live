/*******************************************************************************
 Copyright (C) 2019 Signify Holding
 All Rights Reserved.
 ********************************************************************************/

#import "PHSBridgeResourceCapabilities.h"

@interface PHSBridgeRuleCapabilities : PHSBridgeResourceCapabilities

@property (nonatomic, strong, readonly) NSNumber* availableConditions;

@property (nonatomic, strong, readonly) NSNumber* availableActions;

@end
